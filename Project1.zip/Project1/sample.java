import java.io.File;
import java.util.ArrayList;
import java.util.Scanner;
public class sample
{		

     public static void main(String[] args)
	 {
		 //Render input data
         String strFilePath = "C:\\Users\\Michael\\New Paltz Computer Science 2017\\Operating Systems\\Project1\\input.data";
         Scanner kb;
   
         try
		 {
             kb = new Scanner(new File(strFilePath));
			 
			 //hold input data within an ArrayList of integers
             ArrayList <Integer> input = new ArrayList<>();
        
             //while the input file has more to process 
             while(kb.hasNextInt())
             {
                input.add(kb.nextInt());
             }
	 
	 
	         for(int i : input)
	         {
		        System.out.println(i);
	         }
         }
		 catch(Exception e)
		 {
			 e.printStackTrace();
         }
         
     }
	
}