import java.io.FileNotFoundException;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.Arrays;

public class Algorithm
{
    //declare class objects that are nessesary for algorithm implementation
    private InputFile inputFile;
    private ReadyQueue rQueue;
    private Dispatcher dispatcher;
    private TimeCounter timeCounter;

    //Constructor, receive an input file
    public Algorithm(InputFile inputObject) throws FileNotFoundException, UnsupportedEncodingException {
        //obtain the input data
        this.inputFile = inputObject;

        //instantiate necessary class objects
        this.timeCounter = new TimeCounter(this.inputFile.getQuantum());
        this.dispatcher = new Dispatcher(timeCounter,true);
        this.rQueue = new ReadyQueue();
    }

    //begin the computation
    public void run()
    {
        //run while the either inputFile Job list or the ReadyQueue has elements within it.
        do
        {

            //new jobs arrive at this second? check the current second within the time counter //add or earlier for a larger quantum
            if(checkForJobs(dispatcher.getTimeCounter().getCurrentSecond()))
            {
                //add jobs to the queue
                rQueue.addProcess(getNewJobs(dispatcher.getTimeCounter().getCurrentSecond()));

                //sort the ready queue based on priority  //sort()
                boolean preemptive = isPreemptive();

                //if preemption
                if(preemptive)
                {
                    //remove current process from CPU, send important process to CPU.
                    preemption();
                }
            }

            //is the cpu currently unoccupied?
            if(dispatcher.getCPUStatus())
            {
                //is a process ready to be added from queue?
                if(rQueue.jobQueueSize() > 0)
                {
                    //send process to the CPU
                    dispatcher.setCurrentProcess(rQueue.removeProcess());
                    dispatcher.setCPUStatus(false);
                }


            }    //time to write to an output file
            else if (dispatcher.peekCurrentProcess().getBurstTime() <= 0)
            {
                //write current process to output file
                dispatcher.removeCurrentProcess();

                //the cpu is now available
                dispatcher.setCPUStatus(true);

                //is a process ready to be added from queue?
                if(rQueue.jobQueueSize() > 0)
                {
                    //get next process
                    dispatcher.setCurrentProcess(rQueue.removeProcess());
                }
            }



            //only accessed when a process is being executed by CPU
            if(!dispatcher.getCPUStatus())
            {
                /* check if the current process burst time is less than the quantum; */
                if(dispatcher.peekCurrentProcess().getBurstTime() < timeCounter.getQuantum())
                {
                    //allow job to complete execution
                    timeCounter.setCurrentSecond(dispatcher.peekCurrentProcess().getBurstTime() + timeCounter.getCurrentSecond());

                    //remove current process from the cpu, write to output file.
                    dispatcher.removeCurrentProcess();

                    //DON'T INCREASE CLOCK, IT ALREADY HAS BEEN DONE FOR THIS ITERATION
                }
                else
                {
                    //decrement burst time of PCB object occupying CPU.
                    dispatcher.peekCurrentProcess().setBurstTime(timeCounter.getQuantum());

                    //adjust the current time
                    timeCounter.inc();
                }

            }
            else
            {
                //adjust the current time
                timeCounter.inc();
            }


        }
        while(remainingProcesses());

        //close the output file, we're finished
        dispatcher.getOutputFile().close();
    }

    //preform preemption between the ReadyQueue and the Dispatcher
    private void preemption()
    {
        //remove current process
        PCB removedProcess = dispatcher.removeCurrentProcess();
        ArrayList<PCB> temp = new ArrayList<PCB>();
        temp.add(removedProcess);


        //does the current process need to be added back onto the readyQueue?
        if(removedProcess.getBurstTime() > 0)
        {
            //embark element into new ArrayList, add it back onto the ReadyQueue
            rQueue.addProcess(temp);

            //ensure that the ReadyQueue elements are in proper order //sort();
        }

        //via inductive logic, we know the correct process is a the head of queue.
        dispatcher.setCurrentProcess(rQueue.removeProcess());

    }

    //checks if the algorithm needs to continue running, that is: check if the readyQueue + inputFile lists are empty
    private boolean remainingProcesses()
    {
         //are both lists empty?
         if(rQueue.jobQueueSize() == 0 && inputFile.getPCBAList().size() == 0 && dispatcher.getCPUStatus())
         {
             //stop, we're done.
             return false;
         }

         //there are still jobs that need to be processed
         return true;
    }


    /*INPUTFILE CONTROLLER METHODS*/

    //check if jobs need to be added to the ready queue
    private boolean checkForJobs(int currentSecond) {
        boolean arrivedJob = false;
        for (PCB process : inputFile.getPCBAList()) {
            if (currentSecond >= process.getArrivalTime()) {
                //a job has arrived on the queue
                arrivedJob = true;
            }
        }

        return arrivedJob;
    }

    //remove jobs from input file that "arrive" at this current second
    private ArrayList<PCB> getNewJobs(int currentSecond) {
        //arrived jobs
        ArrayList<PCB> arrivedJobs = new ArrayList<PCB>();

        //add the arrived jobs to a temporary list
        for (PCB process : inputFile.getPCBAList()) {
            if (currentSecond >= process.getArrivalTime()) {
                //a job has arrived
                arrivedJobs.add(process);
            }
        }

        //remove the arrived jobs from the input file object
        inputFile.getPCBAList().removeAll(arrivedJobs);

        // return the jobs that appeared this given second
        return arrivedJobs;
    }

    /*READYQUEUE CONTROLLER METHODS*/

    private boolean isPreemptive() {
        //if-else logic if premptive priority low return T/F
        if(dispatcher.getCPUStatus() == true) {
            return false;
        }
        else if (rQueue.peekProcess().getPriority() < dispatcher.peekCurrentProcess().getPriority()) {
            return true;
        } else {
            return false;
        }

    }

    //helper function to display output to users.
    public void print()
    {
        this.dispatcher.getOutputFile().print();
    }

}
