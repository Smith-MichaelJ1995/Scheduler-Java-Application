import java.io.FileNotFoundException;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.Arrays;

public class Algorithm
{
    //declare class objects that are nessesary for algorithm implementation
    private InputFile inputFile;
    private ReadyQueue rQueue;
    private Dispatcher dispatcher;
    private Output outputFile;

    //Constructor, recieve an input file
    public Algorithm(InputFile inputObject) throws FileNotFoundException, UnsupportedEncodingException {
        //obtain the input data
        this.inputFile = inputObject;

        //instantiate class objects
        this.dispatcher = new Dispatcher(this.inputFile.getQuantum(),true);
        this.rQueue = new ReadyQueue(dispatcher);
        this.outputFile = new Output();
    }

    //begin the computation
    public void run()
    {
        //run while the either inputFile Job list or the ReadyQueue has elements within it.
        do
        {
            //new jobs arrive at this second? check the current second within the time counter
            if(checkForJobs(dispatcher.getTimeCounter().getCurrentSecond()))
            {
                //add jobs to the queue
                rQueue.addProcess(getNewJobs());

                boolean preemptive = sort();
                System.out.println(preemptive);
                System.exit(1);

                if(preemptive)
                {
                    preemption();
                }
            }

            //is the cpu currently unnocupied?
            if(dispatcher.cpuFree())
            {
                //is a process ready to be added from queue?
                if(rQueue.jobQueueSize() > 0)
                {
                    //send process to the CPU
                    dispatcher.setCurrentProcess(rQueue.removeProcess());
                    dispatcher.setCPUStatus(false);
                }
            }    //time to write to an output file
            else if (dispatcher.peekCurrentProcess().getBurstTime() == 0)
            {
                //write to the output file
                outputFile.write(dispatcher.removeCurrentProcess());

                //the cpu is now available
                dispatcher.setCPUStatus(true);

                //is a process ready to be added from queue?
                if(rQueue.jobQueueSize() > 0)
                {
                    //get next process
                    dispatcher.setCurrentProcess(rQueue.removeProcess());
                }
            }
            //adjust the current time
            dispatcher.getTimeCounter().inc();
            dispatcher.peekCurrentProcess().setBurstTime(inputFile.getQuantum());
        }
        while(remainingProcesses());

    }

    //preform preemption between the ReadyQueue and the Dispatcher
    private void preemption()
    {
        PCB removedProcess = dispatcher.removeCurrentProcess();
        //write current process to output file
        outputFile.write(removedProcess);

        //does the current process need to be added back onto the readyQueue?
        if(removedProcess.getBurstTime() > 0)
        {
            //embark element into new ArrayList, add it back onto the ReadyQueue
            rQueue.addProcess(new ArrayList<PCB>() {{
                add(removedProcess);
            }});

            //ensure that the ReadyQueue elements are in proper order
            sort();
        }

        //via inductive logic, we know the correct process is a the head of queue.
        dispatcher.setCurrentProcess(rQueue.removeProcess());

    }

    //checks if the algorithm needs to continue running, that is: check if the readyQueue + inputFile lists are empty
    private boolean remainingProcesses()
    {
         //are both lists empty?
         if(rQueue.jobQueueSize() == 0 && inputFile.getPCBAList().size() == 0)
         {
             //stop, we're done.
             return false;
         }

         //there are still jobs that need to be processed
         return true;
    }


    /*INPUTFILE CONTROLLER METHODS*/

    //check if jobs need to be added to the ready queue
    private boolean checkForJobs(int currentSecond) {
        boolean arrivedJob = false;
        for (PCB process : inputFile.getPCBAList()) {
            if (currentSecond == process.getArrivalTime()) {
                //a job has arrived on the queue
                arrivedJob = true;

                //move the current process to the arrivedJobsList
                inputFile.getPCBAList().remove(process);
                inputFile.getArrivedJobsList().add(process);
            }
        }

        return arrivedJob;
    }

    //returns the jobs that "arrive" at the provided second
    private ArrayList<PCB> getNewJobs() {
        //Allows us to clear the list 'arrivedJobs' list after each second..populate a new list
        ArrayList<PCB> temp = new ArrayList<PCB>();

        for(PCB job : inputFile.getArrivedJobsList()) {   temp.add(job);  }

        //clear the list
        inputFile.getArrivedJobsList().clear();

        // return the jobs that appeared this given second
        return temp;
    }

    /*READYQUEUE CONTROLLER METHODS*/
    private boolean sort() {
        //create an array for the queue elements
        PCB[] processes = new PCB[rQueue.jobQueueSize()];


        int index = 0;
        //fill new array with queue elements for sorting
        while (rQueue.jobQueueSize() > 0) {
            //populate the queue elements into the array
            processes[index++] = rQueue.jobQueue.poll();
        }

        //perform a selection sort on the array elements
        //INSERT PRIORITY PREF HERE
        int targetIndex = 0;
        for (int outerIndex = 0; outerIndex < processes.length; outerIndex++) {
            targetIndex = outerIndex;
            for (int innerIndex = outerIndex + 1; innerIndex < processes.length; innerIndex++) {
                if (processes[targetIndex].getPriority() > processes[innerIndex].getPriority()) {
                    targetIndex = innerIndex;
                }
            }
            //swap the elements
            PCB temp = processes[outerIndex];
            processes[outerIndex] = processes[targetIndex];
            processes[targetIndex] = temp;
        }


        //convert array of sorted elements back into a queue
        rQueue.addProcess(new ArrayList<PCB>(Arrays.asList(processes)));

        //if-else logic if premptive priority low return T/F
        if(dispatcher.cpuFree() == true) {
            return false;
        }
        else if (rQueue.peekProcess().getPriority() < dispatcher.peekCurrentProcess().getPriority()) {
            return true;
        } else {
            return false;
        }

    }

}
