public class TimeCounter
{
    //integer representation of the current second
    private int currentSecond;
    private int quantum;

    //Constructor..set clock to '0'.
    public TimeCounter(int quantum)
    {
        this.currentSecond = 0;
        this.quantum = quantum;
    }

    //get the current second value
    public int getCurrentSecond() {   return this.currentSecond;   }

    //get the current second value
    public int getQuantum() {   return this.quantum;   }

    //increase the time according to the quantum value
    public void inc()  {  this.currentSecond +=  quantum;   }

    //for case where quantum is greater than burst time of a process
    public void setCurrentSecond(int currentSecond) { this.currentSecond = currentSecond; }
}