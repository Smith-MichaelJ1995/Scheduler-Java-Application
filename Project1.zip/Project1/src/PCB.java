public class PCB {
    //each process has these properties
    private int arrivalTime;
    private int burstTime;
    private int priority;
    private int processNumber;
    private int startTime;
    private int endTime;

    //contructor
    public PCB(int arrivalTime, int burstTime, int priority, int processNumber) {
        this.arrivalTime = arrivalTime;
        this.burstTime = burstTime;
        this.priority = priority;
        this.processNumber = processNumber;
    }

    //getters
    public int getArrivalTime() {
        return arrivalTime;
    }

    public int getBurstTime() {
        return burstTime;
    }

    public int getPriority() {
        return priority;
    }

    public int getProcessNumber() {
        return processNumber;
    }

    public int getStartTime() {
        return startTime;
    }

    public int getEndTime() {
        return endTime;
    }

    //setters for start time + end time, burst time
    public void setStartTime(int startTime) {
        this.startTime = startTime;
    }

    public void setEndTime(int endTime) {
        this.endTime = endTime;
    }

    //set burst time after an interation of algorithm
    public void setBurstTime(int quantum) { this.burstTime -= quantum; }

}