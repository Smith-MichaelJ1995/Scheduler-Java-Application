public class PCB implements Comparable<PCB> {

    //each process has these properties
    private int arrivalTime;
    private int burstTime;
    private int priority;
    private int processNumber;

    //contructor
    public PCB(int arrivalTime, int burstTime, int priority, int processNumber) {
        this.arrivalTime = arrivalTime;
        this.burstTime = burstTime;
        this.priority = priority;
        this.processNumber = processNumber;
    }

    //getters
    public int getArrivalTime() {
        return arrivalTime;
    }

    public int getBurstTime() {
        return burstTime;
    }

    public int getPriority() {
        return priority;
    }

    public int getProcessNumber() {
        return processNumber;
    }

    //set burst time after an interation of algorithm
    public void setBurstTime(int quantum) { this.burstTime -= quantum; }

    //implementation of compareTo function, lower #'s mean higher priority
    //CAN CONFIGURE ANY 'PRIORITY' SORTING HERE
    public int compareTo(PCB job)
    {
        //if this value is negative, than (this.priority() < job.priority().. so on.
        return this.getPriority() - job.getPriority();
    }

}