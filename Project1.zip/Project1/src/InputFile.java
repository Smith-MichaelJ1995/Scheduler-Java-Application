import java.util.ArrayList;

public class InputFile {

    //each input file has the following properties in their first 2 lines
    private int totalNumberProcesses;
    private int algoType;
    private int quantum;

    //Dynamic object representation of the processes in the input file
    private ArrayList<PCB> pcbAList;

    //Constructor
    public InputFile(int totalNumberProcesses, int algoType, int quantum) {
        //assign local values
        this.totalNumberProcesses = totalNumberProcesses;
        this.algoType = algoType;
        this.quantum = quantum;

        //instantiate the PCB object list.
        pcbAList = new ArrayList<PCB>();
    }

    //displays the input file in a neatly formatted String
    public void print()
    {
        //the "head" of the input file
        String head = this.totalNumberProcesses + "\n" + this.algoType + " " + this.quantum + "\n";

        //build string containing data from each pcb object
        String body = "";

        for(PCB p : pcbAList)
        {
           body += p.getArrivalTime() + " " + p.getBurstTime() + " " + p.getPriority() + "\n";
        }

        System.out.println("INPUT FILE:" + "\n" + head + body);
    }

    //set the process list
    public void setPcbAList(ArrayList<PCB> pcbAList) {
        this.pcbAList = pcbAList;
    }

    //'getter' methods
    public int getTotalNumberProcesses() {
        return this.totalNumberProcesses;
    }

    public int getAlgoType() {
        return this.algoType;
    }

    public int getQuantum() {
        return this.quantum;
    }

    //get the process list
    public ArrayList<PCB> getPCBAList() {
        return this.pcbAList;
    }

}