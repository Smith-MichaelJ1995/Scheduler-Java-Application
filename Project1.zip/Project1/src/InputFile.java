import java.util.ArrayList;

public class InputFile {
    //each input file has the following properties in their first 2 lines
    private int totalNumberProcesses;
    private int algoType;
    private int quantum;

    //Object representation of the processes in the input file
    private ArrayList<PCB> pcbAList;

    //Holds the jobs that "arrive" after each second in time
    private ArrayList<PCB> arrivedJobs;

    //Constructor
    public InputFile(int totalNumberProcesses, int algoType, int quantum) {
        //assign local values
        this.totalNumberProcesses = totalNumberProcesses;
        this.algoType = algoType;
        this.quantum = quantum;

        //instantiate the PCB object list.
        pcbAList = new ArrayList<PCB>();
        arrivedJobs = new ArrayList<PCB>();

    }

    //set the process list
    public void setPcbAList(ArrayList<PCB> pcbAList) {
        this.pcbAList = pcbAList;
    }

    //'getter' methods
    public int getTotalNumberProcesses() {
        return this.totalNumberProcesses;
    }

    public int getAlgoType() {
        return this.algoType;
    }

    public int getQuantum() {
        return this.quantum;
    }

    //get the process list
    public ArrayList<PCB> getPCBAList() {
        return this.pcbAList;
    }

    //get arrived jobs list
    public ArrayList<PCB> getArrivedJobsList() {
        return this.arrivedJobs;
    }


}