import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;

public class Output
{
    //object representation of the output text file
    PrintWriter outputFile;

    //Constructor
    public Output() throws FileNotFoundException, UnsupportedEncodingException {
        this.outputFile =  new PrintWriter("output.data", "UTF-8");
    }

    public void write(PCB currentProcess)
    {
        outputFile.println(currentProcess.getStartTime() + "(start)  " + currentProcess.getStartTime() + "(end)  " + currentProcess.getProcessNumber() + " (process #)");
    }


    public void close() {   outputFile.close();  }

}
