import java.io.FileNotFoundException;
import java.io.PrintWriter;

import java.io.UnsupportedEncodingException;

public class Output
{
    //object representation of the output text file
    private PrintWriter outputFile;

    //output string message for user
    private String outputText;

    //Constructor
    public Output() throws FileNotFoundException, UnsupportedEncodingException {
        //declare file values
        this.outputFile =  new PrintWriter("output.data", "UTF-8");

        //initialize output string
        this.outputText = "";
    }
    //write parameter text to output file
    public void write(String output)
    {
        //print to output file
        outputFile.print(output);

        //build output file
        outputText += output;
    }

    public void print()
    {
        System.out.println("OUTPUT FILE:" + "\n" + this.outputText);
    }

    //close the output file
    public void close() {   outputFile.close();  }

}
