import java.io.FileNotFoundException;
import java.io.UnsupportedEncodingException;

public class Dispatcher
{
    //the process currently occupying the CPU
    private PCB currentProcess;

    //the current time of the clock
    private TimeCounter tc;

    //writes to the output file
    private Output outputFile;

    //if the CPU is currently available
    private boolean cpuFree;


    //Constructor
    public Dispatcher(TimeCounter tc, boolean status) throws FileNotFoundException, UnsupportedEncodingException
    {
        this.tc = tc;
        this.cpuFree = status;

        this.outputFile = new Output();
    }

    //return the current process   FIX
    public PCB peekCurrentProcess()
    {
        return this.currentProcess;
    }

    public PCB removeCurrentProcess()
    {
        //time to remove this process from the CPU
        this.cpuFree = true;

        //write end time and current 'process #' to the output file
        this.outputFile.write(this.tc.getCurrentSecond() + "(end) " + this.currentProcess.getProcessNumber() + "(process #)" + "\n");

        return this.currentProcess;
    }

    public boolean getCPUStatus() {    return this.cpuFree;  }

    public TimeCounter getTimeCounter() {     return this.tc;    }

    public Output getOutputFile() {
        return outputFile;
    }

    public void setCPUStatus(boolean status)  {    this.cpuFree = status;     }

    //assign the current process equal to a new parameter
    public void setCurrentProcess(PCB incomingProcess)
    {
        this.currentProcess = incomingProcess;

        //The CPU is now occupied
        this.cpuFree = false;

        //write time that 'currentProcess' accesses the CPU
        this.outputFile.write(this.tc.getCurrentSecond() + "(start) ");
    }


}