
public class Dispatcher
{
    //the process currently occupying the CPU
    private PCB currentProcess;

    //if the CPU is currently available
    private boolean cpuFree;

    //the current time of the clock
    private TimeCounter tc;

    //Constructor
    public Dispatcher(int quantum, boolean status)
    {
        this.tc = new TimeCounter(quantum);
        this.cpuFree = status;
    }

    //return the current process   FIX
    public PCB peekCurrentProcess()
    {
        return this.currentProcess;
    }

    public PCB removeCurrentProcess()
    {
        //time to remove this process from the CPU
        this.cpuFree = true;

        //write end time to current process..get the second value
        currentProcess.setEndTime(tc.getCurrentSecond());

        return this.currentProcess;
    }

    public boolean cpuFree() {    return this.cpuFree;  }

    public TimeCounter getTimeCounter() {     return this.tc;    }

    public void setCPUStatus(boolean status)  {    this.cpuFree = status;     }

    //assign the current process equal to a new parameter
    public void setCurrentProcess(PCB incomingProcess)
    {
        this.currentProcess = incomingProcess;

        //The CPU is now occupied
        this.cpuFree = false;

        //write the start time to the current PCB
        this.currentProcess.setStartTime(tc.getCurrentSecond());
    }



}