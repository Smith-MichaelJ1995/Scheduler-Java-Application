import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;
import java.util.ArrayList;

public class ProcessInput {
    //declare inputfile object
    private InputFile fileObject;

    //render the input file, convert to an input object
    public ProcessInput() throws FileNotFoundException {
        fileObject = buildInputObject();
    }


    //return the input file for processing
    public InputFile getInputFileObject() {
        return this.fileObject;
    }

    //build and return an object representation of the input.data file
    private InputFile buildInputObject() throws FileNotFoundException {

        //pull data as an ArrayList of Integers
        ArrayList<Integer> inputData = processInputFile();
        ArrayList<PCB> processes = new ArrayList<PCB>();
        int processNumber = 0;

        //set ttl# of processes, algoType
        InputFile data = new InputFile(inputData.get(0), inputData.get(1), inputData.get(2));

        int inputCounter = 3;

        while (inputCounter < inputData.size()) {
            int arrival = inputData.get(inputCounter++);
            int burstTime = inputData.get(inputCounter++);
            int priority = inputData.get(inputCounter++);

            PCB job = new PCB(arrival, burstTime, priority, processNumber++);

            processes.add(job);
        }

        //add ArrayList of Processes to data (InputObject)
        data.setPcbAList(processes);

        //return the object; given an Integer representation of the input, create an object and pass it back.
        return data;

    }

    //processes an input file and returns its contents
    private ArrayList<Integer> processInputFile() throws FileNotFoundException {

        Scanner kb = new Scanner(new File("C:\\Users\\Michael\\New Paltz Computer Science 2017\\Operating Systems\\Project1\\input.data"));

        ArrayList<Integer> input = new ArrayList<Integer>();
        while (kb.hasNextInt()) {
            input.add(kb.nextInt());
        }

        //closing the scanner
        kb.close();

        return input;
    }

}