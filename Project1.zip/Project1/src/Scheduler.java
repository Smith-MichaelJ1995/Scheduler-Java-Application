import java.io.FileNotFoundException;
import java.io.UnsupportedEncodingException;

public class Scheduler
{
    public static void main(String[] args) throws FileNotFoundException, UnsupportedEncodingException {
        //read input file, build an object representation of input.data
        ProcessInput input = new ProcessInput();

        System.out.println("INPUT FILE:");
        //display contents of inputfile object
        System.out.println(input.getInputFileObject().getTotalNumberProcesses());
        System.out.println(input.getInputFileObject().getAlgoType() + " " + input.getInputFileObject().getQuantum());
        for(PCB job : input.getInputFileObject().getPCBAList())
        {
            System.out.println(job.getArrivalTime() + " " + job.getBurstTime() + " " + job.getPriority());
        }


        //contains all classes needed for CPUScheduling Algorithm
        Algorithm scheduler = new Algorithm(input.getInputFileObject());

        //begin the computation
        scheduler.run();

        System.out.println("SUCCESS, NO ERRORS");
    }
}
