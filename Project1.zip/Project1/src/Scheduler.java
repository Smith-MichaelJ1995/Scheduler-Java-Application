import java.io.FileNotFoundException;
import java.io.UnsupportedEncodingException;

public class Scheduler
{
    public static void main(String[] args) throws FileNotFoundException, UnsupportedEncodingException {

        //read input file, build an object representation of input.data
        ProcessInput input = new ProcessInput();

        //display contents of input file object
        input.getInputFileObject().print();

        //contains all classes needed for CPUScheduling Algorithm
        Algorithm scheduler = new Algorithm(input.getInputFileObject());

        //begin the computation
        scheduler.run();

        //print the output file to screen
        scheduler.print();

    }
}
