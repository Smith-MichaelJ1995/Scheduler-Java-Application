import java.util.ArrayList;
import java.util.PriorityQueue;

public class ReadyQueue
{
    //the ready queue object
    PriorityQueue<PCB> jobQueue;

    //Holds a reference to the dispatcher object
    Dispatcher dispatcher;

    //Constructor
    public ReadyQueue(Dispatcher dispatcher)
    {
        //initialize the dispatcher
        this.dispatcher = dispatcher;

        // initialize the queue
        this.jobQueue = new PriorityQueue<PCB>();
    }

    //add one or more new processes to the ready queue
    public void addProcess(ArrayList<PCB> arrivedJobs)
    {
        for(PCB job : arrivedJobs)
        {
            this.jobQueue.add(job);
        }

    }

    //removes and returns the process at the head of the queue
    public PCB removeProcess()
    {
        return this.jobQueue.poll();
    }

    //returns the process at the head of the queue without removing
    public PCB peekProcess()
    {
        return this.jobQueue.peek();
    }

    //returns the current size of the queue
    public int jobQueueSize()
    {
        return this.jobQueue.size();
    }

}
