import java.util.ArrayList;
import java.util.Iterator;
import java.util.PriorityQueue;

public class ReadyQueue
{
    //the ready queue object
    private PriorityQueue<PCB> jobQueue;

    //Constructor
    public ReadyQueue()
    {
        // initialize the queue
        this.jobQueue = new PriorityQueue<PCB>();
    }

    //add one or more new processes to the ready queue
    public void addProcess(ArrayList<PCB> arrivedJobs)
    {
        this.jobQueue.addAll(arrivedJobs);
    }

    //removes and returns the process at the head of the queue
    public PCB removeProcess()
    {
        return this.jobQueue.poll();
    }

    //returns the process at the head of the queue without removing
    public PCB peekProcess()
    {
        return this.jobQueue.peek();
    }

    //returns the current size of the queue
    public int jobQueueSize()
    {
        return this.jobQueue.size();
    }

}
